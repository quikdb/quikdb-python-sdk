# Define constants in Python

production = True
is_prod = True
SERVER_URL = 'https://quikdb-core-beta.onrender.com' if is_prod else 'http://localhost:4567'
